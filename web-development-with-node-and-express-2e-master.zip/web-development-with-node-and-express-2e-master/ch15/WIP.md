* The data store for attractions uses MongoDB...what to do?  Could replace with an in-memory fake and leave database implementation as a reader's exercise....
* Re-factoring to expose "vacations" API.  A little bit awkward with DEL and the testing framework.
* Currently working on testing framework.  Not a very good test as it relies on seed data, but will explain away in copy.
* I think I'm going to drop the connect-rest plugin stuff.


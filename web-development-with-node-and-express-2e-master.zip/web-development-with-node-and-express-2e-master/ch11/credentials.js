module.exports = {
  cookieSecret: '924c53cb-479e-42b5-b6b6-0f5d97cd3a07',
  sendgrid: {
    user: 'apikey',
    password: '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',
  },
}

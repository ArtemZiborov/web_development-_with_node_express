# WIP

* Almost done with Postgres example.
* Need to figure out how to do "vacation in season listener"...handle that update, etc.  Also, sessionstore doesn't support Postgres, so that's awkward. (hint: use "ON CONFLICT DO NOTHING" or "ON CONFLICT DO UPDATE")
* Also, there's some commented-out code about flash messages surrounding the currency thing....
* in general this chapter feels very slapdash
* needs some section & structure for sure
